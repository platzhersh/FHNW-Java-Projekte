package jdraw.figures.handles.states;

import java.awt.Cursor;
import java.awt.Point;

public class HandleStateNE extends AbstractHandleState {

	@Override
	public AbstractHandleState getHorizontalFlipState() {
		return new HandleStateNW();
	}

	@Override
	public AbstractHandleState getVerticalFlipState() {
		return new HandleStateSW();
	}

	@Override
	public Cursor getCursor() {
		return Cursor.getPredefinedCursor(Cursor.NE_RESIZE_CURSOR);
	}

	@Override
	public Point getLocation() {
		Point l = owner.getBounds().getLocation();
		l.x += owner.getBounds().width;
		return l;
	}
	
	@Override
	public Point getAnchor() {
		// anchor is HandleStateSW
		Point l = owner.getBounds().getLocation();
		l.x += owner.getBounds().width;
		l.y += owner.getBounds().height;
		return l;
	}

	@Override
	public void dragInteraction(int x, int y) {
		// TODO Auto-generated method stub
		
	}
}
